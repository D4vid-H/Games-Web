

const LUCHADORUNO = {
    id: '1',
    nombre: "Superman",
    golpeBajo: 11,
    golpeFuerte: 20,
    vida: 250,
    especial: 100
}

const LUCHADORDOS = {
    id: '2',
    nombre: "Batman",
    golpeBajo: 10,
    golpeFuerte: 22,
    vida: 250,
    especial: 100
}

const imgBatmangolpeFuerte = 'batmanfuerte.jpg';
const imgBatmangolpeBajo = 'batmandebil.jpg';
const imgBatmanGolpeEspecial = 'batmanespecial.jpg';
const imgBatmanWin = 'batmanwin.jpg';
const imgSupermanGolpeFuerte = 'supermanfuerte.jpg';
const imgSupermanGolpeBajo = 'supermandebil.jpg';
const imgSupermanGolpeEspecial = 'supermanespecial.jpg';
const imgSupermanWin = 'supermanwin.jpg';

const golpeSuperman = (superman, batman) => {

    let {vida} = batman;
        (Math.ceil(Math.random() * (50)) + 1) === 16 && perderVida(vida, superman.especial, imgSupermanGolpeEspecial, superman);
    
        vida = (Math.ceil(Math.random() * (5)) + 1) === 3 ? perderVida(vida, superman.golpeFuerte, imgSupermanGolpeFuerte, superman) : perderVida(vida, superman.golpeBajo, imgSupermanGolpeBajo, superman);
   
        batman.vida = vida;   
}

const golpeBatman = (batman, superman) => {

    let {vida} = superman;
        (Math.ceil(Math.random() * (50)) + 1) === 16 && perderVida(vida, batman.especial, imgBatmanGolpeEspecial, batman);
     
        vida = (Math.ceil(Math.random() * (5)) + 1) === 3 ? perderVida(vida, batman.golpeFuerte, imgBatmangolpeFuerte, batman) : perderVida(vida, batman.golpeBajo, imgBatmangolpeBajo, batman);

        superman.vida = vida; 
     
}

 const perderVida = (vida, golpe, img, luchador) =>{

    console.log(`Se activo el golpe ${golpe}`);
    dibujarEscena(img, luchador);
    vida = vida - golpe;
    return vida;
}

const dibujarEscena = (image, luchador) => {

    const div = document.createElement('div');
        div.setAttribute('class', 'recuadro__img');
        document.body.appendChild(div).innerHTML = `
        <div class="text__formato"><img class="align-left" src="./img/${image}">${luchador.nombre} conecta un golpe</div>   
    `
}


do{

    (Math.ceil(Math.random() * (5 - 3)) + 0) === 1 ? golpeSuperman(LUCHADORUNO, LUCHADORDOS) : golpeBatman(LUCHADORDOS, LUCHADORUNO);

}while(LUCHADORUNO.vida >= 0 && LUCHADORDOS.vida >= 0);

LUCHADORDOS.vida <= 0 ? dibujarEscena(imgSupermanWin, LUCHADORUNO) : dibujarEscena(imgBatmanWin, LUCHADORDOS);

